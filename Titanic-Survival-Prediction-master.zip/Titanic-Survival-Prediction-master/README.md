Overview:

•	Importing Datasets

•	Performing EDA

•	Imputation

•	Visual analysis of some attributes

•	Identifying the redundant features for prediction using co-relation coefficient and P-value

•	Implementing Logistic Regression model

•	Checking Model accuracy using Confusion Matrix, f1_score and accuracy score  

•	Fine tuning with Random Classifier model

•	Deploying for prediction



